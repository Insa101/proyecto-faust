-- Creación de la base de datos
CREATE DATABASE IF NOT EXISTS biblioteca CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;

-- Elección de la base de datos
USE biblioteca;

-- Creación de las entidades
CREATE TABLE IF NOT EXISTS autores(
	id_autor INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(45) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    fnac DATE,
    PRIMARY KEY(id_autor)
)ENGINE = InnoDB;